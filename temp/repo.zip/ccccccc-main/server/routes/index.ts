import aiRappersRouter from "./aiRappers";
import aiSongsRouter from "./aiSongs";
import aiAlbumsRouter from "./aiAlbums";
import chartHistoryRouter from "./chartHistory";

export {
  aiRappersRouter,
  aiSongsRouter,
  aiAlbumsRouter,
  chartHistoryRouter
};