// Re-export from useRapperGame.ts
// This file exists to maintain compatibility with imports in the codebase
export * from './useRapperGame.ts';